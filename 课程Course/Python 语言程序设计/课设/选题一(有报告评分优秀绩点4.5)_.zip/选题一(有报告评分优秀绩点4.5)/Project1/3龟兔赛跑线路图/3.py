import numpy as np
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties

# 设置中文字体，防止出现乱码
font = FontProperties(fname='C:/Windows/Fonts/simhei.ttf')

# 定义时间范围
t = np.linspace(0, 10, 1000)

# 使用分段函数定义兔子的行走轨迹
rabbit = np.piecewise(t, 
                      [t < 2, (t >= 2) & (t < 4), t >= 4],
                      [lambda t: 5*t, 
                       10, 
                       lambda t: 2*(t-4) + 10])

# 使用线性函数定义乌龟的行走轨迹
turtle = 1 * t

# 绘制兔子和乌龟的时间-位移图像
plt.plot(t, rabbit, label='兔子')
plt.plot(t, turtle, label='乌龟')

# 添加标题和标签，并应用中文字体
plt.title('龟兔赛跑', fontproperties=font)
plt.xlabel('时间', fontproperties=font)
plt.ylabel('位移', fontproperties=font)
plt.legend(prop=font)
plt.grid(True)

# 显示图像
plt.show()
