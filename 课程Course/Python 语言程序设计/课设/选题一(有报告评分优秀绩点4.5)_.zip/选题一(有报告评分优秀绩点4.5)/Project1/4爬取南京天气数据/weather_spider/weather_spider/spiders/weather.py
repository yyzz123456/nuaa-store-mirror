import scrapy
import os
import re

class WeatherSpider(scrapy.Spider):
    name = 'weather'  # 这是爬虫的名称
    start_urls = ['https://www.tianqi.com/nanjing/']  # 初始爬取的URL列表

    def parse(self, response):
        """
        解析天气预报网页内容并保存到本地文件

        参数:
        response (scrapy.http.Response): 爬取的网页响应

        返回值:
        无
        """
        # 使用XPath选择包含'cityname'的<script>标签中的文本内容
        city_script = response.xpath("//script[contains(text(), 'cityname')]/text()").get()
        # 使用正则表达式从提取的JavaScript内容中匹配城市名称
        city_match = re.search(r"var cityname = '(.*?)';", city_script)
        # 提取城市名称，如果匹配成功，则提取城市名称；否则，设置为'未知'
        city = city_match.group(1) if city_match else '未知'

        # 将城市名称记录到日志中
        self.log(f"城市: {city}")

        # 使用CSS选择器从网页中提取包含天气预报信息的元素
        forecast = response.css('dl.weather_info')
        # 确定输出文件路径，文件名为'weather.txt'
        output_file = os.path.abspath('weather.txt')
        
        # 打开文件并写入数据
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(f"城市：{city}\n")
            # 遍历提取的天气信息，逐条写入日期、天气描述、温度、湿度、风向、紫外线指数和空气质量等数据
            for day in forecast:
                # 提取日期信息
                date = day.css('dd.week::text').get()
                # 提取天气描述
                weather_desc = day.css('dd.weather span b::text').get()
                # 提取温度信息，并进行格式化
                temperature = day.css('dd.weather span::text').get().strip().replace(' ', '').replace('~', ' ~ ')
                # 提取湿度信息
                humidity = day.css('dd.shidu b:nth-child(1)::text').get().replace('湿度：', '')
                # 提取风向信息
                wind = day.css('dd.shidu b:nth-child(2)::text').get().replace('风向：', '')
                # 提取紫外线指数
                uv_index = day.css('dd.shidu b:nth-child(3)::text').get().replace('紫外线：', '')
                # 提取空气质量信息
                air_quality = day.css('dd.kongqi h5::text').get().replace('空气质量：', '')

                # 将提取的信息写入文件
                f.write(f"日期：{date}\n")
                f.write(f"天气：{weather_desc}\n")
                f.write(f"温度：{temperature}\n")
                f.write(f"湿度：{humidity}\n")
                f.write(f"风向：{wind}\n")
                f.write(f"紫外线：{uv_index}\n")
                f.write(f"空气质量：{air_quality}\n")
                f.write("\n")
        
        # 记录日志，提示数据已成功写入文件
        self.log(f"天气数据已写入 {output_file} 文件！")



