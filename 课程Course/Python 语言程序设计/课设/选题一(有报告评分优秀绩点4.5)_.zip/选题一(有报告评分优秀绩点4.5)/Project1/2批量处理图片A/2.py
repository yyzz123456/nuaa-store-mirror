import os
def create_html_from_images(image_folder):
    """
    参数: image_folder (str): 存放图片的文件夹路径
    返回值: 无
    """
    # 获取文件夹中的所有图片文件
    images = [img for img in os.listdir(image_folder) if img.endswith(('png', 'jpg', 'jpeg', 'gif'))]
    images.sort()  # 按名称排序
    html_content = '<html><body>\n'
    
    # 生成HTML内容
    for img in images:
        html_content += f'<img src="{image_folder}/{img}" alt="{img}">\n'
    html_content += '</body></html>'
    
    # 将HTML内容写入文件
    with open('output.html', 'w', encoding='utf-8') as f:
        f.write(html_content)
    
    print("HTML文件创建完成！")
# 替换为你的图片文件夹路径
create_html_from_images(r'C:\Users\Administrator\Desktop\Project\Project1\Photos')

