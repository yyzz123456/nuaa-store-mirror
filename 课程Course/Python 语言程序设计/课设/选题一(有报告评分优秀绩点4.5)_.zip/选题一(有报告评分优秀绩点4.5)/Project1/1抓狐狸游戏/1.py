import random
def catch_the_fox(max_steps=3):
    """
   参数: max_steps (int): 玩家可以尝试抓狐狸的最大次数
返回值: bool: 玩家是否成功抓到狐狸
    """
    # 初始化狐狸的位置
    fox_position = random.randint(0, 4)
    print("狐狸的位置初始化完成！")

    # 玩家有 max_steps 次尝试机会
    for step in range(1, max_steps + 1):
        try:
            # 接收玩家输入的洞口编号
            guess = int(input(f"第{step}次尝试：请选择一个洞口（0-4）："))
            if guess < 0 or guess > 4:
                raise ValueError("输入的洞口编号无效！")
        except ValueError as ve:
            print(ve)
            continue

        # 判断玩家是否抓到狐狸
        if guess == fox_position:
            print("恭喜你，抓到狐狸了！")
            return True
        else:
            print("没抓到狐狸，狐狸跑到隔壁洞口了！")
            # 狐狸移动到隔壁洞口
            if fox_position == 0:
                fox_position += 1
            elif fox_position == 4:
                fox_position -= 1
            else:
                fox_position += random.choice([-1, 1])
    
    print("很遗憾，所有尝试次数已用完，游戏结束。")
    return False
catch_the_fox()
